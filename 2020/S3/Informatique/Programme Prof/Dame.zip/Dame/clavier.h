#ifndef __CLAVIER_H__
#define __CLAVIER_H__

void keyboard(unsigned char key, int x, int y);
#endif
