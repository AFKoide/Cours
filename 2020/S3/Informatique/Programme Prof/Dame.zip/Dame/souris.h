#ifndef __SOURIS_H__
#define __SOURIS_H__

void mouseDrag(int xs,int ys);
void mouse(int button, int state,int xs, int ys);

#endif
