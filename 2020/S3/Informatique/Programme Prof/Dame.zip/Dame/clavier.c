#include <stdlib.h>



void keyboard(unsigned char key, int x, int y)
{ if(key==27) //ESCAPE key
    {	  exit (0);
    }

}
